
import React, { useState, useRef, useEffect } from 'react';
import { FileFormat } from './types';
import { analyzeDocumentPage } from './services/geminiService';
import { generatePPTX, generateDOCX, generateXLSX, generateCSV, generatePDFFromImages } from './services/documentGenerator';

const MAX_FILE_SIZE = 1024 * 1024 * 1024; // 1GB

const FORMAT_CONFIG = {
  [FileFormat.PDF]: { icon: 'fa-file-pdf', color: 'text-rose-500', bg: 'bg-rose-50' },
  [FileFormat.DOCX]: { icon: 'fa-file-word', color: 'text-blue-500', bg: 'bg-blue-50' },
  [FileFormat.PPTX]: { icon: 'fa-file-powerpoint', color: 'text-orange-500', bg: 'bg-orange-50' },
  [FileFormat.XLSX]: { icon: 'fa-file-excel', color: 'text-emerald-500', bg: 'bg-emerald-50' },
  [FileFormat.CSV]: { icon: 'fa-file-csv', color: 'text-teal-500', bg: 'bg-teal-50' },
  [FileFormat.MPP]: { icon: 'fa-project-diagram', color: 'text-indigo-500', bg: 'bg-indigo-50' },
  [FileFormat.PNG]: { icon: 'fa-file-image', color: 'text-purple-500', bg: 'bg-purple-50' },
  [FileFormat.JPG]: { icon: 'fa-file-image', color: 'text-pink-500', bg: 'bg-pink-50' },
  [FileFormat.TXT]: { icon: 'fa-file-alt', color: 'text-slate-500', bg: 'bg-slate-50' },
};

const useExternalScripts = () => {
  useEffect(() => {
    const scripts = [
      'https://cdn.jsdelivr.net/npm/pptxgenjs@3.12.0/dist/pptxgen.bundle.js',
      'https://cdn.jsdelivr.net/npm/docx@8.5.0/build/index.js',
      'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js',
      'https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js',
      'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js'
    ];
    scripts.forEach(src => {
      const script = document.createElement('script');
      script.src = src;
      script.async = false;
      document.head.appendChild(script);
    });
  }, []);
};

const App: React.FC = () => {
  useExternalScripts();
  
  const [file, setFile] = useState<File | null>(null);
  const [sourceFormat, setSourceFormat] = useState<FileFormat>(FileFormat.PDF);
  const [targetFormat, setTargetFormat] = useState<FileFormat>(FileFormat.DOCX);
  const [isConverting, setIsConverting] = useState(false);
  const [progress, setProgress] = useState(0);
  const [status, setStatus] = useState('');
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      if (selectedFile.size > MAX_FILE_SIZE) {
        setError(`File is too large! Maximum limit is 1GB. Your file: ${(selectedFile.size / 1024 / 1024 / 1024).toFixed(2)}GB`);
        setFile(null);
        return;
      }
      setFile(selectedFile);
      setError(null);
      const ext = selectedFile.name.split('.').pop()?.toLowerCase() as FileFormat;
      if (Object.values(FileFormat).includes(ext)) {
        setSourceFormat(ext);
      }
    }
  };

  const convertFileToImages = async (file: File): Promise<string[]> => {
    const fileType = file.name.split('.').pop()?.toLowerCase();
    
    if (fileType === 'pdf') {
      const pdfjsLib = (window as any).pdfjsLib;
      pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
      const arrayBuffer = await file.arrayBuffer();
      const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
      const images: string[] = [];
      for (let i = 1; i <= pdf.numPages; i++) {
        const page = await pdf.getPage(i);
        const viewport = page.getViewport({ scale: 2 });
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');
        canvas.height = viewport.height;
        canvas.width = viewport.width;
        await page.render({ canvasContext: context, viewport }).promise;
        images.push(canvas.toDataURL('image/jpeg', 0.8).split(',')[1]);
      }
      return images;
    } else if (['png', 'jpg', 'jpeg'].includes(fileType || '')) {
      return new Promise((resolve) => {
        const reader = new FileReader();
        reader.onload = () => resolve([(reader.result as string).split(',')[1]]);
        reader.readAsDataURL(file);
      });
    }
    return []; 
  };

  const handleConvert = async () => {
    if (!file) {
      setError("Please select a file first.");
      return;
    }
    setIsConverting(true);
    setProgress(5);
    setStatus('Scanning document structure...');
    setError(null);

    try {
      const images = await convertFileToImages(file);
      setProgress(20);

      let outputBlob: Blob;
      
      if (images.length > 0 && [FileFormat.DOCX, FileFormat.PPTX, FileFormat.XLSX, FileFormat.CSV].includes(targetFormat)) {
        setStatus('AI Analyzing visual elements...');
        const allPagesData: any[] = [];
        for (let i = 0; i < images.length; i++) {
          setStatus(`Processing page ${i + 1} of ${images.length}...`);
          const result = await analyzeDocumentPage(images[i]);
          allPagesData.push(...result.pages);
          setProgress(20 + ((i + 1) / images.length) * 60);
        }
        const combinedResult = { pages: allPagesData };
        
        if (targetFormat === FileFormat.DOCX) outputBlob = await generateDOCX(combinedResult);
        else if (targetFormat === FileFormat.PPTX) outputBlob = await generatePPTX(combinedResult);
        else if (targetFormat === FileFormat.XLSX) outputBlob = await generateXLSX(combinedResult);
        else if (targetFormat === FileFormat.CSV) outputBlob = await generateCSV(combinedResult);
        else throw new Error("Format not handled.");
      } 
      else if (targetFormat === FileFormat.PDF && images.length > 0) {
        setStatus('Creating PDF document...');
        outputBlob = await generatePDFFromImages(images);
      }
      else if (targetFormat === FileFormat.PNG || targetFormat === FileFormat.JPG) {
        setStatus('Exporting frames...');
        const byteCharacters = atob(images[0]);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) byteNumbers[i] = byteCharacters.charCodeAt(i);
        outputBlob = new Blob([new Uint8Array(byteNumbers)], { type: `image/${targetFormat}` });
      }
      else {
        throw new Error(`Direct conversion from ${sourceFormat} to ${targetFormat} is not yet supported for this specific file type.`);
      }

      const url = URL.createObjectURL(outputBlob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `multi_converted.${targetFormat}`;
      a.click();
      URL.revokeObjectURL(url);

      setProgress(100);
      setStatus('Conversion complete!');
      setTimeout(() => setIsConverting(false), 2000);
    } catch (err: any) {
      setError(err.message || 'Conversion failed. The AI couldn\'t process this document correctly.');
      setIsConverting(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center pt-12 pb-20 px-6">
      {/* Header Area */}
      <header className="w-full max-w-6xl flex flex-col md:flex-row justify-between items-center gap-6 mb-16">
        <div className="flex items-center gap-4 group cursor-pointer">
          <div className="w-14 h-14 jazzy-gradient rounded-2xl flex items-center justify-center text-white text-2xl shadow-xl transition-all duration-500 group-hover:scale-110 group-hover:rotate-[360deg]">
            <i className="fas fa-magic"></i>
          </div>
          <div className="flex flex-col">
            <h1 className="text-3xl font-black tracking-tight text-slate-900 leading-none uppercase">
              MULTI<span className="text-indigo-600">CONVERTER</span>
            </h1>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.4em] mt-1">High-Fidelity AI Lab</span>
          </div>
        </div>
        
        <div className="flex items-center gap-8 text-sm font-extrabold text-slate-500 uppercase tracking-widest">
          <span className="hover:text-indigo-600 cursor-pointer">Features</span>
          <span className="hover:text-indigo-600 cursor-pointer">Support</span>
        </div>
      </header>

      {/* Main Stage */}
      <main className="w-full max-w-4xl relative">
        <div className="text-center mb-16">
          <h2 className="text-5xl md:text-7xl font-black text-slate-900 mb-6 tracking-tighter leading-tight">
            The Ultimate <br/> <span className="bg-clip-text text-transparent jazzy-gradient">Format Transmuter.</span>
          </h2>
          <p className="text-xl font-medium text-slate-500 max-w-xl mx-auto">
            Lossless AI conversion for all your documents. Upload up to <span className="text-slate-900 font-bold">1GB</span> of data instantly.
          </p>
        </div>

        {/* Converter Card */}
        <div className="glass-card-light rounded-[48px] p-8 md:p-16 relative overflow-hidden transition-all duration-700">
          
          {/* Progress Overlay */}
          {isConverting && (
            <div className="absolute inset-0 z-50 bg-white/95 backdrop-blur-xl flex flex-col items-center justify-center p-10 text-center animate-in fade-in duration-500">
              <div className="w-36 h-36 relative mb-12">
                <svg className="w-full h-full transform -rotate-90">
                  <circle cx="72" cy="72" r="64" stroke="#f1f5f9" strokeWidth="12" fill="transparent" />
                  <circle 
                    cx="72" cy="72" r="64" 
                    stroke="url(#grad1)" 
                    strokeWidth="12" 
                    fill="transparent" 
                    strokeLinecap="round"
                    className="transition-all duration-700 ease-out" 
                    strokeDasharray={402.12} 
                    strokeDashoffset={402.12 - (402.12 * progress) / 100} 
                  />
                  <defs>
                    <linearGradient id="grad1" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#6366f1" />
                      <stop offset="100%" stopColor="#ec4899" />
                    </linearGradient>
                  </defs>
                </svg>
                <div className="absolute inset-0 flex items-center justify-center font-black text-3xl text-slate-900">
                  {Math.round(progress)}%
                </div>
              </div>
              <h3 className="text-4xl font-black text-slate-900 mb-4 tracking-tight">{status}</h3>
              <p className="text-slate-400 font-bold uppercase tracking-[0.2em] text-xs">Don't close this window</p>
            </div>
          )}

          <div className="flex flex-col gap-12">
            
            {/* Formats Selection */}
            <div className="grid md:grid-cols-[1fr,auto,1fr] items-center gap-6">
              <div className="flex flex-col gap-3">
                <label className="text-[11px] font-black text-slate-400 uppercase tracking-widest px-1">Source Format</label>
                <div className="relative group">
                  <select 
                    value={sourceFormat}
                    onChange={(e) => setSourceFormat(e.target.value as FileFormat)}
                    className="w-full bg-slate-50 border-2 border-slate-100 rounded-3xl py-5 px-14 font-extrabold text-slate-700 focus:border-indigo-500 transition-all outline-none cursor-pointer"
                  >
                    {Object.values(FileFormat).map(f => <option key={f} value={f}>{f.toUpperCase()}</option>)}
                  </select>
                  <div className={`absolute left-5 top-1/2 -translate-y-1/2 text-2xl ${FORMAT_CONFIG[sourceFormat].color}`}>
                    <i className={`fas ${FORMAT_CONFIG[sourceFormat].icon}`}></i>
                  </div>
                </div>
              </div>

              <div className="flex justify-center pt-6">
                <div className="w-14 h-14 bg-indigo-50 rounded-full flex items-center justify-center text-indigo-600 shadow-inner float-jazzy">
                  <i className="fas fa-sync text-xl"></i>
                </div>
              </div>

              <div className="flex flex-col gap-3">
                <label className="text-[11px] font-black text-slate-400 uppercase tracking-widest px-1">Target Format</label>
                <div className="relative group">
                  <select 
                    value={targetFormat}
                    onChange={(e) => setTargetFormat(e.target.value as FileFormat)}
                    className="w-full bg-slate-50 border-2 border-slate-100 rounded-3xl py-5 px-14 font-extrabold text-slate-700 focus:border-indigo-500 transition-all outline-none cursor-pointer"
                  >
                    {Object.values(FileFormat).map(f => <option key={f} value={f}>{f.toUpperCase()}</option>)}
                  </select>
                  <div className={`absolute left-5 top-1/2 -translate-y-1/2 text-2xl ${FORMAT_CONFIG[targetFormat].color}`}>
                    <i className={`fas ${FORMAT_CONFIG[targetFormat].icon}`}></i>
                  </div>
                </div>
              </div>
            </div>

            {/* Drop Zone */}
            <div 
              onClick={() => fileInputRef.current?.click()}
              className={`group relative border-4 border-dashed rounded-[40px] p-16 transition-all duration-500 cursor-pointer flex flex-col items-center justify-center gap-8
                ${file ? 'border-indigo-400 bg-indigo-50/30' : 'border-slate-100 hover:border-indigo-200 hover:bg-slate-50'}
              `}
            >
              <input type="file" ref={fileInputRef} className="hidden" onChange={handleFileChange} />
              
              <div className={`w-32 h-32 rounded-3xl flex items-center justify-center text-5xl shadow-2xl transition-all duration-500 group-hover:scale-110 group-hover:rotate-6
                ${file ? 'jazzy-gradient text-white shadow-indigo-200' : 'bg-white text-indigo-500 shadow-xl shadow-slate-200'}
              `}>
                <i className={file ? "fas fa-check-circle" : "fas fa-cloud-arrow-up"}></i>
              </div>
              
              <div className="text-center">
                <h4 className="text-3xl font-black text-slate-900 mb-2 tracking-tight">
                  {file ? file.name : "Unleash Your File"}
                </h4>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-[0.3em]">
                  {file ? `${(file.size / 1024 / 1024).toFixed(2)} MB` : `Upto 1GB • ${sourceFormat.toUpperCase()} Preferred`}
                </p>
              </div>

              {file && (
                <button 
                  onClick={(e) => { e.stopPropagation(); setFile(null); }}
                  className="absolute top-10 right-10 w-12 h-12 bg-white shadow-xl rounded-2xl flex items-center justify-center text-slate-300 hover:text-rose-500 transition-all"
                >
                  <i className="fas fa-times"></i>
                </button>
              )}
            </div>

            {/* Notification & Action */}
            <div className="flex flex-col gap-8">
              {error && (
                <div className="p-6 bg-rose-50 border-2 border-rose-100 rounded-3xl text-rose-600 font-bold text-sm flex items-center gap-4 animate-in slide-in-from-top-4 duration-300">
                  <div className="w-10 h-10 rounded-full bg-rose-500 text-white flex items-center justify-center shrink-0">
                    <i className="fas fa-exclamation-triangle"></i>
                  </div>
                  <span>{error}</span>
                </div>
              )}
              
              <div className="flex justify-center">
                <button
                  disabled={!file || isConverting}
                  onClick={handleConvert}
                  className={`jazzy-btn w-full max-w-md py-5 rounded-3xl font-black text-xl text-white flex items-center justify-center gap-6
                    ${file && !isConverting ? '' : 'opacity-40 grayscale cursor-not-allowed'}
                  `}
                >
                  <span>TRANSMUTE TO {targetFormat.toUpperCase()}</span>
                  <i className="fas fa-bolt"></i>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Feature Highlights */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-20">
          {[
            { label: 'Pixel Perfect', icon: 'fa-eye', color: 'text-indigo-600', bg: 'bg-indigo-50' },
            { label: 'Editable Output', icon: 'fa-pen-to-square', color: 'text-rose-600', bg: 'bg-rose-50' },
            { label: 'Gemini AI Core', icon: 'fa-brain-circuit', color: 'text-purple-600', bg: 'bg-purple-50' },
            { label: '1GB Cloud Limit', icon: 'fa-cloud-arrow-up', color: 'text-sky-600', bg: 'bg-sky-50' }
          ].map((item, i) => (
            <div key={i} className="glass-card-light p-6 rounded-[32px] flex flex-col items-center text-center gap-4 hover:-translate-y-2 transition-all duration-300 group cursor-default">
              <div className={`w-14 h-14 ${item.bg} ${item.color} rounded-2xl flex items-center justify-center text-xl transition-all duration-500 group-hover:scale-110 group-hover:rotate-[15deg]`}>
                <i className={`fas ${item.icon}`}></i>
              </div>
              <span className="font-extrabold text-slate-400 text-[10px] uppercase tracking-[0.3em] leading-tight">{item.label}</span>
            </div>
          ))}
        </div>
      </main>

      <footer className="mt-24 text-center">
        <p className="text-slate-400 font-bold text-[10px] uppercase tracking-[0.5em]">
          Innovating Documents &copy; 2024 MultiConverter
        </p>
      </footer>
    </div>
  );
};

export default App;
