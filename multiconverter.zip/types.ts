
export enum FileFormat {
  PDF = 'pdf',
  DOCX = 'docx',
  PPTX = 'pptx',
  XLSX = 'xlsx',
  CSV = 'csv',
  MPP = 'mpp',
  PNG = 'png',
  JPG = 'jpg',
  TXT = 'txt'
}

export interface ConversionRequest {
  sourceFile: File;
  sourceFormat: FileFormat;
  targetFormat: FileFormat;
}

export interface DocumentElement {
  type: 'text' | 'image' | 'shape' | 'table';
  content: string;
  x: number;
  y: number;
  width: number;
  height: number;
  fontSize?: number;
  fontColor?: string;
  isBold?: boolean;
  alignment?: 'left' | 'center' | 'right';
  rows?: any[][];
}

export interface DocumentPage {
  pageNumber: number;
  elements: DocumentElement[];
}

export interface ConversionResult {
  pages: DocumentPage[];
}
