
declare const pptxgen: any;
declare const docx: any;
declare const XLSX: any;
declare const jspdf: any;

export const generatePPTX = async (conversionResult: any): Promise<Blob> => {
  const PptxGenJS = (window as any).PptxGenJS;
  const pres = new PptxGenJS();
  conversionResult.pages.forEach((page: any) => {
    const slide = pres.addSlide();
    page.elements.forEach((el: any) => {
      if (el.type === 'text') {
        slide.addText(el.content, {
          x: `${el.x}%`, y: `${el.y}%`, w: `${el.width}%`, h: `${el.height}%`,
          fontSize: el.fontSize || 11, color: el.fontColor?.replace('#', '') || '000000',
          bold: el.isBold, align: el.alignment || 'left'
        });
      }
    });
  });
  return await pres.write('blob');
};

export const generateDOCX = async (conversionResult: any): Promise<Blob> => {
  const { Document, Packer, Paragraph, TextRun, AlignmentType } = (window as any).docx;
  const sections = conversionResult.pages.map((page: any) => ({
    children: page.elements.sort((a: any, b: any) => a.y - b.y).map((el: any) => new Paragraph({
      alignment: el.alignment === 'center' ? AlignmentType.CENTER : el.alignment === 'right' ? AlignmentType.RIGHT : AlignmentType.LEFT,
      children: [new TextRun({ text: el.content, bold: el.isBold, size: (el.fontSize || 11) * 2, color: el.fontColor?.replace('#', '') || '000000' })],
    })),
  }));
  const doc = new Document({ sections });
  return await Packer.toBlob(doc);
};

export const generateXLSX = async (conversionResult: any): Promise<Blob> => {
  const XLSX = (window as any).XLSX;
  const wb = XLSX.utils.book_new();
  
  // Attempt to extract tabular data from elements
  const data: any[][] = [];
  conversionResult.pages.forEach((page: any) => {
    page.elements.forEach((el: any) => {
      if (el.type === 'text') {
        // Simple heuristic: map y-coord to rows, x-coord to columns
        const row = Math.floor(el.y / 5);
        const col = Math.floor(el.x / 15);
        if (!data[row]) data[row] = [];
        data[row][col] = el.content;
      }
    });
  });

  const ws = XLSX.utils.aoa_to_sheet(data);
  XLSX.utils.book_append_sheet(wb, ws, "Sheet1");
  const wbout = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
  return new Blob([wbout], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
};

export const generateCSV = async (conversionResult: any): Promise<Blob> => {
  const XLSX = (window as any).XLSX;
  const data: any[][] = [];
  conversionResult.pages.forEach((page: any) => {
    page.elements.forEach((el: any) => {
      const row = Math.floor(el.y / 5);
      const col = Math.floor(el.x / 15);
      if (!data[row]) data[row] = [];
      data[row][col] = el.content;
    });
  });
  const ws = XLSX.utils.aoa_to_sheet(data);
  const csv = XLSX.utils.sheet_to_csv(ws);
  return new Blob([csv], { type: 'text/csv' });
};

export const generatePDFFromImages = async (images: string[]): Promise<Blob> => {
  const { jsPDF } = (window as any).jspdf;
  const doc = new jsPDF();
  for (let i = 0; i < images.length; i++) {
    if (i > 0) doc.addPage();
    const imgData = `data:image/jpeg;base64,${images[i]}`;
    doc.addImage(imgData, 'JPEG', 0, 0, 210, 297);
  }
  return doc.output('blob');
};
