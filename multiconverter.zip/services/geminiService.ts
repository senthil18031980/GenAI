
import { GoogleGenAI, Type } from "@google/genai";
import { ConversionResult } from "../types";

export const analyzeDocumentPage = async (base64Image: string): Promise<ConversionResult> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: {
      parts: [
        {
          inlineData: {
            mimeType: 'image/jpeg',
            data: base64Image,
          },
        },
        {
          text: `Analyze this document page image and extract all visual elements with high precision.
          Preserve the exact positions (x, y coordinates in percentage 0-100), dimensions (width, height in percentage), 
          content, and styling (font size, color, bold, alignment).
          
          Identify:
          1. Text blocks: content, style, position.
          2. Headings: usually larger text.
          3. Basic shapes or regions.
          
          Return a JSON structure matching this schema:
          {
            "pages": [
              {
                "pageNumber": 1,
                "elements": [
                  {
                    "type": "text",
                    "content": "the actual text",
                    "x": 10, "y": 15, "width": 80, "height": 5,
                    "fontSize": 12, "fontColor": "#000000", "isBold": false, "alignment": "left"
                  }
                ]
              }
            ]
          }`
        }
      ]
    },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          pages: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                pageNumber: { type: Type.NUMBER },
                elements: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      type: { type: Type.STRING },
                      content: { type: Type.STRING },
                      x: { type: Type.NUMBER },
                      y: { type: Type.NUMBER },
                      width: { type: Type.NUMBER },
                      height: { type: Type.NUMBER },
                      fontSize: { type: Type.NUMBER },
                      fontColor: { type: Type.STRING },
                      isBold: { type: Type.BOOLEAN },
                      alignment: { type: Type.STRING }
                    },
                    required: ["type", "content", "x", "y", "width", "height"]
                  }
                }
              }
            }
          }
        }
      }
    }
  });

  try {
    const data = JSON.parse(response.text.trim());
    return data as ConversionResult;
  } catch (error) {
    console.error("Failed to parse Gemini response:", error);
    throw new Error("Could not interpret document layout.");
  }
};
